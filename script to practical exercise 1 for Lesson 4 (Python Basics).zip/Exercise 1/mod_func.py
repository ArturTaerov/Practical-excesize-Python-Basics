

def pay_calc (out_ph, rat_ph, bon):
    """ Принимает три позиционных аргумента (выработка в часах, ставка в час,\
        премия) и возвращает сумму заработной платы сотрудника."""
    pay = float(out_ph)*float(rat_ph) + float(bon)
    return pay


