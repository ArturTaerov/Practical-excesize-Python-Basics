# -*- coding: utf-8 -*-
"""
Created on Mon May  2 14:41:12 2022

@author: Артур
"""

from sys import argv
from itertools import cycle

scr2, ln2 = argv

sp = [5, 1, 7, 4, 3, 8]
        
j = 0
for i in cycle(sp):
    if j > int(ln2):
        break
    print(i)
    j+= 1