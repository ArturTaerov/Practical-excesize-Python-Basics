# -*- coding: utf-8 -*-
"""
Created on Mon May  2 13:49:41 2022

@author: Артур
"""
from sys import argv
from itertools import count

scr1, ln, ln_gl = argv 

for i in count(int(ln)):
    if i > int(ln_gl):
        break
    else:
        print (i)
